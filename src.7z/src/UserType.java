public enum UserType
{
    ADMIN,
    STUDENT,
    TEACHER
}
