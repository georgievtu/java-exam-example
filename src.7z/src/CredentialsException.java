public class CredentialsException extends Exception
{
    public CredentialsException(String msg)
    {
        super(msg);
    }
}
